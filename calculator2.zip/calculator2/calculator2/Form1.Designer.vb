﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.txtInput2 = New System.Windows.Forms.TextBox()
        Me.rdbPlus = New System.Windows.Forms.RadioButton()
        Me.rdbMinus = New System.Windows.Forms.RadioButton()
        Me.rdbTimes = New System.Windows.Forms.RadioButton()
        Me.rdbDivide = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnEquals = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(272, 117)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(100, 20)
        Me.txtInput.TabIndex = 0
        '
        'txtInput2
        '
        Me.txtInput2.Location = New System.Drawing.Point(272, 220)
        Me.txtInput2.Name = "txtInput2"
        Me.txtInput2.Size = New System.Drawing.Size(100, 20)
        Me.txtInput2.TabIndex = 1
        '
        'rdbPlus
        '
        Me.rdbPlus.AutoSize = True
        Me.rdbPlus.Location = New System.Drawing.Point(35, 7)
        Me.rdbPlus.Name = "rdbPlus"
        Me.rdbPlus.Size = New System.Drawing.Size(31, 17)
        Me.rdbPlus.TabIndex = 2
        Me.rdbPlus.TabStop = True
        Me.rdbPlus.Text = "+"
        Me.rdbPlus.UseVisualStyleBackColor = True
        '
        'rdbMinus
        '
        Me.rdbMinus.AutoSize = True
        Me.rdbMinus.Location = New System.Drawing.Point(35, 30)
        Me.rdbMinus.Name = "rdbMinus"
        Me.rdbMinus.Size = New System.Drawing.Size(28, 17)
        Me.rdbMinus.TabIndex = 3
        Me.rdbMinus.TabStop = True
        Me.rdbMinus.Text = "-"
        Me.rdbMinus.UseVisualStyleBackColor = True
        '
        'rdbTimes
        '
        Me.rdbTimes.AutoSize = True
        Me.rdbTimes.Location = New System.Drawing.Point(35, 53)
        Me.rdbTimes.Name = "rdbTimes"
        Me.rdbTimes.Size = New System.Drawing.Size(29, 17)
        Me.rdbTimes.TabIndex = 4
        Me.rdbTimes.TabStop = True
        Me.rdbTimes.Text = "*"
        Me.rdbTimes.UseVisualStyleBackColor = True
        '
        'rdbDivide
        '
        Me.rdbDivide.AutoSize = True
        Me.rdbDivide.Location = New System.Drawing.Point(35, 76)
        Me.rdbDivide.Name = "rdbDivide"
        Me.rdbDivide.Size = New System.Drawing.Size(30, 17)
        Me.rdbDivide.TabIndex = 5
        Me.rdbDivide.TabStop = True
        Me.rdbDivide.Text = "/"
        Me.rdbDivide.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdbMinus)
        Me.GroupBox1.Controls.Add(Me.rdbDivide)
        Me.GroupBox1.Controls.Add(Me.rdbPlus)
        Me.GroupBox1.Controls.Add(Me.rdbTimes)
        Me.GroupBox1.Location = New System.Drawing.Point(418, 117)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(348, 123)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        '
        'btnEquals
        '
        Me.btnEquals.Location = New System.Drawing.Point(453, 259)
        Me.btnEquals.Name = "btnEquals"
        Me.btnEquals.Size = New System.Drawing.Size(75, 23)
        Me.btnEquals.TabIndex = 7
        Me.btnEquals.Text = "="
        Me.btnEquals.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnEquals)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtInput2)
        Me.Controls.Add(Me.txtInput)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtInput As TextBox
    Friend WithEvents txtInput2 As TextBox
    Friend WithEvents rdbPlus As RadioButton
    Friend WithEvents rdbMinus As RadioButton
    Friend WithEvents rdbTimes As RadioButton
    Friend WithEvents rdbDivide As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnEquals As Button
End Class
