﻿Public Class Form1
    Dim answer As Integer
    Private Sub btnEquals_Click(sender As Object, e As EventArgs) Handles btnEquals.Click
        If rdbPlus.Checked Then answer = Val(txtInput.Text) + Val(txtInput2.Text)
        If rdbMinus.Checked Then answer = Val(txtInput.Text) - Val(txtInput2.Text)
        If rdbTimes.Checked Then answer = Val(txtInput.Text) * Val(txtInput2.Text)
        If rdbDivide.Checked Then answer = Val(txtInput.Text) / Val(txtInput2.Text)
        MessageBox.Show(answer)

    End Sub
End Class
