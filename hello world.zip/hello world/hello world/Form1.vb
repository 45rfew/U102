﻿Public Class Form1
    Private Sub btnmessage_Click(sender As Object, e As EventArgs) Handles btnmessage.Click
        MessageBox.Show("asdsa")

    End Sub
End Class
