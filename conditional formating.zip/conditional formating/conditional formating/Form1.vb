﻿Public Class Form1
    Private Sub btnMessage_Click(sender As Object, e As EventArgs) Handles btnMessage.Click
        Dim apple = "apple"
        If apple = "banana" Then btnMessage.Text = "apple" Else btnMessage.Text = "banana"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim creamcake As String
        Dim DietState As String
        creamcake = TextBox1.Text
        Select Case creamcake
            Case "Eaten"
                DietState = "Diet Ruined"
            Case "Not Eaten"
                DietState = "Diet Not Ruined"
            Case Else
                DietState = "Didn't check"
        End Select
        MessageBox.Show(DietState)
    End Sub
End Class
