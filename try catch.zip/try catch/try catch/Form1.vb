﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Label1.Text = splitstring(TextBox1.Text)
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Sub
    Public Function splitstring(str) As String
        Try
            Dim split = str.split(" ")
            'For Each i In split
            '    If split(i) = "." Or "," Then
            '        split(i) = ""
            '    End If
            'Next
            Return split
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Function

End Class
