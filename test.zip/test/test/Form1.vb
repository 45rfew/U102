﻿Public Class Form1
    Dim message = ""
    Private Sub btnMessage1_Click(sender As Object, e As EventArgs) Handles btnMessage1.Click
        message += "a"
        txtDisplay.Text = message
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        message = ""
        txtDisplay.Text = message
    End Sub
End Class
