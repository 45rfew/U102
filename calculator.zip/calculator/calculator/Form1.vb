﻿Public Class Form1
    Dim number As Integer
    Dim number2 As Integer
    Dim total As Integer
    ReadOnly operators = {"Plus", "Minus", "Times", "Divide"}
    Dim lastOp = ""
    Dim init = False
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnOne.Click
        txtNum.Text &= btnOne.Text
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnTwo.Click
        txtNum.Text &= btnTwo.Text
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnThree.Click
        txtNum.Text &= btnThree.Text
    End Sub
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnFour.Click
        txtNum.Text &= btnFour.Text
    End Sub
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btnFive.Click
        txtNum.Text &= btnFive.Text
    End Sub
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles btnSix.Click
        txtNum.Text &= btnSix.Text
    End Sub
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles btnSeven.Click
        txtNum.Text &= btnSeven.Text
    End Sub
    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles btnEight.Click
        txtNum.Text &= btnEight.Text
    End Sub
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles btnNine.Click
        txtNum.Text &= btnNine.Text
    End Sub
    Private Sub btnPlus_Click(sender As Object, e As EventArgs) Handles btnPlus.Click
        number2 += Val(txtNum.Text)
        txtNum.Text = ""
        lastOp = "Plus"
    End Sub
    Private Sub btnMinus_Click(sender As Object, e As EventArgs) Handles btnMinus.Click
        number2 += Val(txtNum.Text)
        txtNum.Text = ""
        lastOp = "Minus"
    End Sub
    Private Sub btnTimes_Click(sender As Object, e As EventArgs) Handles btnTimes.Click
        number2 += Val(txtNum.Text)
        txtNum.Text = ""
        lastOp = "Times"
    End Sub
    Private Sub btnDivide_Click(sender As Object, e As EventArgs) Handles btnDivide.Click
        number2 += Val(txtNum.Text)
        txtNum.Text = ""
        lastOp = "Divide"
    End Sub
    Private Sub btnEqual_Click(sender As Object, e As EventArgs) Handles btnEqual.Click
        Select Case lastOp
            Case "Plus"
                txtNum.Text = number2 + Val(txtNum.Text)
            Case "Minus"
                txtNum.Text = number2 - Val(txtNum.Text)
            Case "Times"
                txtNum.Text = number2 * Val(txtNum.Text)
            Case "Divide"
                txtNum.Text = number2 / Val(txtNum.Text)
        End Select
        init = True
    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        number2 = 0
        txtNum.Clear()
    End Sub
End Class
