﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim testString As String = "apple    pear banana  "
        Dim testArray() As String = Split(testString)
        ' testArray holds {"apple", "", "", "", "pear", "banana", "", ""}
        Dim lastNonEmpty As Integer = -1
        For i As Integer = 0 To testArray.Length - 1
            If testArray(i) <> "" Then
                lastNonEmpty += 1
                testArray(lastNonEmpty) = testArray(i)
            End If
        Next
        ReDim Preserve testArray(lastNonEmpty)
        ' testArray now holds {"apple", "pear", "banana"}
        Dim a As String = ""
        For Each i In testArray
            a += i
        Next
        MessageBox.Show(a)
    End Sub
End Class