﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtheightinput = New System.Windows.Forms.TextBox()
        Me.txtweightinput = New System.Windows.Forms.TextBox()
        Me.btncalculate = New System.Windows.Forms.Button()
        Me.lblheight = New System.Windows.Forms.Label()
        Me.lblweight = New System.Windows.Forms.Label()
        Me.lblbmi = New System.Windows.Forms.Label()
        Me.lbloutput = New System.Windows.Forms.Label()
        Me.lblresult = New System.Windows.Forms.Label()
        Me.lblclass = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtheightinput
        '
        Me.txtheightinput.Location = New System.Drawing.Point(475, 115)
        Me.txtheightinput.Name = "txtheightinput"
        Me.txtheightinput.Size = New System.Drawing.Size(100, 31)
        Me.txtheightinput.TabIndex = 0
        '
        'txtweightinput
        '
        Me.txtweightinput.Location = New System.Drawing.Point(475, 188)
        Me.txtweightinput.Name = "txtweightinput"
        Me.txtweightinput.Size = New System.Drawing.Size(100, 31)
        Me.txtweightinput.TabIndex = 2
        '
        'btncalculate
        '
        Me.btncalculate.Location = New System.Drawing.Point(280, 398)
        Me.btncalculate.Name = "btncalculate"
        Me.btncalculate.Size = New System.Drawing.Size(253, 40)
        Me.btncalculate.TabIndex = 3
        Me.btncalculate.Text = "calculate"
        Me.btncalculate.UseVisualStyleBackColor = True
        '
        'lblheight
        '
        Me.lblheight.AutoSize = True
        Me.lblheight.Location = New System.Drawing.Point(219, 115)
        Me.lblheight.Name = "lblheight"
        Me.lblheight.Size = New System.Drawing.Size(113, 25)
        Me.lblheight.TabIndex = 4
        Me.lblheight.Text = "height(cm)"
        '
        'lblweight
        '
        Me.lblweight.AutoSize = True
        Me.lblweight.Location = New System.Drawing.Point(219, 191)
        Me.lblweight.Name = "lblweight"
        Me.lblweight.Size = New System.Drawing.Size(111, 25)
        Me.lblweight.TabIndex = 5
        Me.lblweight.Text = "weight(kg)"
        '
        'lblbmi
        '
        Me.lblbmi.AutoSize = True
        Me.lblbmi.Location = New System.Drawing.Point(219, 282)
        Me.lblbmi.Name = "lblbmi"
        Me.lblbmi.Size = New System.Drawing.Size(58, 25)
        Me.lblbmi.TabIndex = 6
        Me.lblbmi.Text = "bmi="
        '
        'lbloutput
        '
        Me.lbloutput.AutoSize = True
        Me.lbloutput.Location = New System.Drawing.Point(475, 261)
        Me.lbloutput.Name = "lbloutput"
        Me.lbloutput.Size = New System.Drawing.Size(0, 25)
        Me.lbloutput.TabIndex = 7
        '
        'lblresult
        '
        Me.lblresult.AutoSize = True
        Me.lblresult.Location = New System.Drawing.Point(470, 340)
        Me.lblresult.Name = "lblresult"
        Me.lblresult.Size = New System.Drawing.Size(0, 25)
        Me.lblresult.TabIndex = 8
        '
        'lblclass
        '
        Me.lblclass.AutoSize = True
        Me.lblclass.Location = New System.Drawing.Point(224, 340)
        Me.lblclass.Name = "lblclass"
        Me.lblclass.Size = New System.Drawing.Size(96, 25)
        Me.lblclass.TabIndex = 9
        Me.lblclass.Text = "bmiclass"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblclass)
        Me.Controls.Add(Me.lblresult)
        Me.Controls.Add(Me.lbloutput)
        Me.Controls.Add(Me.lblbmi)
        Me.Controls.Add(Me.lblweight)
        Me.Controls.Add(Me.lblheight)
        Me.Controls.Add(Me.btncalculate)
        Me.Controls.Add(Me.txtweightinput)
        Me.Controls.Add(Me.txtheightinput)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtheightinput As TextBox
    Friend WithEvents txtweightinput As TextBox
    Friend WithEvents btncalculate As Button
    Friend WithEvents lblheight As Label
    Friend WithEvents lblweight As Label
    Friend WithEvents lblbmi As Label
    Friend WithEvents lbloutput As Label
    Friend WithEvents lblresult As Label
    Friend WithEvents lblclass As Label
End Class
