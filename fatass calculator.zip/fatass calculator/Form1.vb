﻿Public Class Form1
    Private Sub btncalculate_Click(sender As Object, e As EventArgs) Handles btncalculate.Click
        Dim h As Integer = Val(txtheightinput.Text), w As Integer = Val(txtweightinput.Text), bmi
		bmi = Math.Round((w / (h ^ 2)) * 10000, 2) 'calculate bmi
		lbloutput.Text = bmi
		Bmiclass(bmi, lblresult) 'inputing bmi to find weightclass
	End Sub
	Private Function Bmiclass(bmi, textbox) As Integer
		Select Case bmi
			Case 0.0 To 18.5
				textbox.Text = "Underweight"
			Case 18.6 To 24.9
				textbox.Text = "Normal Weight"
			Case 25.0 To 29.9
				textbox.Text = "Overweight"
			Case 30 To 34.9
				textbox.Text = "Obese class I"
			Case 35.0 To 39.9
				textbox.Text = "Obese class II"
			Case Is >= 40
				textbox.Text = "Fatass"
			Case Else
				textbox.Text = "Unable to Determin BMI"
		End Select
	End Function
End Class
