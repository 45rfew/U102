﻿Public Class Form1
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim MyVariable As String

        MyVariable = ComboBox1.Text

        MessageBox.Show(MyVariable)

    End Sub
End Class
