﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmpizzaorder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmpizzaorder))
        Me.grpsizes = New System.Windows.Forms.GroupBox()
        Me.optextra = New System.Windows.Forms.RadioButton()
        Me.optlarge = New System.Windows.Forms.RadioButton()
        Me.optmed = New System.Windows.Forms.RadioButton()
        Me.optsmall = New System.Windows.Forms.RadioButton()
        Me.btnorder = New System.Windows.Forms.Button()
        Me.cboflavour = New System.Windows.Forms.ComboBox()
        Me.chkdeliver = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpsizes.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpsizes
        '
        Me.grpsizes.Controls.Add(Me.optextra)
        Me.grpsizes.Controls.Add(Me.optlarge)
        Me.grpsizes.Controls.Add(Me.optmed)
        Me.grpsizes.Controls.Add(Me.optsmall)
        Me.grpsizes.Location = New System.Drawing.Point(230, 175)
        Me.grpsizes.Margin = New System.Windows.Forms.Padding(6)
        Me.grpsizes.Name = "grpsizes"
        Me.grpsizes.Padding = New System.Windows.Forms.Padding(6)
        Me.grpsizes.Size = New System.Drawing.Size(410, 463)
        Me.grpsizes.TabIndex = 0
        Me.grpsizes.TabStop = False
        Me.grpsizes.Text = "pizza size"
        '
        'optextra
        '
        Me.optextra.AutoSize = True
        Me.optextra.Location = New System.Drawing.Point(54, 296)
        Me.optextra.Margin = New System.Windows.Forms.Padding(6)
        Me.optextra.Name = "optextra"
        Me.optextra.Size = New System.Drawing.Size(145, 29)
        Me.optextra.TabIndex = 3
        Me.optextra.TabStop = True
        Me.optextra.Text = "extra large"
        Me.optextra.UseVisualStyleBackColor = True
        '
        'optlarge
        '
        Me.optlarge.AutoSize = True
        Me.optlarge.Location = New System.Drawing.Point(54, 219)
        Me.optlarge.Margin = New System.Windows.Forms.Padding(6)
        Me.optlarge.Name = "optlarge"
        Me.optlarge.Size = New System.Drawing.Size(91, 29)
        Me.optlarge.TabIndex = 2
        Me.optlarge.TabStop = True
        Me.optlarge.Text = "large"
        Me.optlarge.UseVisualStyleBackColor = True
        '
        'optmed
        '
        Me.optmed.AutoSize = True
        Me.optmed.Location = New System.Drawing.Point(54, 144)
        Me.optmed.Margin = New System.Windows.Forms.Padding(6)
        Me.optmed.Name = "optmed"
        Me.optmed.Size = New System.Drawing.Size(118, 29)
        Me.optmed.TabIndex = 1
        Me.optmed.TabStop = True
        Me.optmed.Text = "medium"
        Me.optmed.UseVisualStyleBackColor = True
        '
        'optsmall
        '
        Me.optsmall.AutoSize = True
        Me.optsmall.Location = New System.Drawing.Point(54, 71)
        Me.optsmall.Margin = New System.Windows.Forms.Padding(6)
        Me.optsmall.Name = "optsmall"
        Me.optsmall.Size = New System.Drawing.Size(93, 29)
        Me.optsmall.TabIndex = 0
        Me.optsmall.TabStop = True
        Me.optsmall.Text = "small"
        Me.optsmall.UseVisualStyleBackColor = True
        '
        'btnorder
        '
        Me.btnorder.BackgroundImage = CType(resources.GetObject("btnorder.BackgroundImage"), System.Drawing.Image)
        Me.btnorder.Location = New System.Drawing.Point(868, 464)
        Me.btnorder.Margin = New System.Windows.Forms.Padding(6)
        Me.btnorder.Name = "btnorder"
        Me.btnorder.Size = New System.Drawing.Size(139, 43)
        Me.btnorder.TabIndex = 1
        Me.btnorder.Text = "order now "
        Me.btnorder.UseVisualStyleBackColor = True
        '
        'cboflavour
        '
        Me.cboflavour.AllowDrop = True
        Me.cboflavour.FormattingEnabled = True
        Me.cboflavour.Items.AddRange(New Object() {"pineapple", "meatlover", "vegan", "fruit"})
        Me.cboflavour.Location = New System.Drawing.Point(868, 246)
        Me.cboflavour.Margin = New System.Windows.Forms.Padding(6)
        Me.cboflavour.Name = "cboflavour"
        Me.cboflavour.Size = New System.Drawing.Size(238, 33)
        Me.cboflavour.TabIndex = 2
        '
        'chkdeliver
        '
        Me.chkdeliver.AutoSize = True
        Me.chkdeliver.Location = New System.Drawing.Point(868, 363)
        Me.chkdeliver.Margin = New System.Windows.Forms.Padding(6)
        Me.chkdeliver.Name = "chkdeliver"
        Me.chkdeliver.Size = New System.Drawing.Size(108, 29)
        Me.chkdeliver.TabIndex = 3
        Me.chkdeliver.Text = "deliver"
        Me.chkdeliver.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.875!)
        Me.Label1.Location = New System.Drawing.Point(666, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(277, 55)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Pizza Order"
        '
        'frmpizzaorder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1600, 865)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.chkdeliver)
        Me.Controls.Add(Me.cboflavour)
        Me.Controls.Add(Me.btnorder)
        Me.Controls.Add(Me.grpsizes)
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.Name = "frmpizzaorder"
        Me.Text = "pizzaorder"
        Me.grpsizes.ResumeLayout(False)
        Me.grpsizes.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpsizes As GroupBox
    Friend WithEvents optextra As RadioButton
    Friend WithEvents optlarge As RadioButton
    Friend WithEvents optmed As RadioButton
    Friend WithEvents optsmall As RadioButton
    Friend WithEvents btnorder As Button
    Friend WithEvents cboflavour As ComboBox
    Friend WithEvents chkdeliver As CheckBox
    Friend WithEvents Label1 As Label
End Class
