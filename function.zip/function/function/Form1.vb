﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Call B()
    End Sub
    Private Sub B()
        Dim a As String = TextBox1.Text.Trim()
        If a = "" Then MessageBox.Show("input name")
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Call AddNumbers(txtFirstNumber.Text, txtSecondNumber.Text)
    End Sub
    Private Sub AddNumbers(first, second)
        Dim answer As Integer = Val(first) + Val(second)
        MessageBox.Show("The total is " & answer)
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim isError As Boolean = check()
        If isError Then Exit Sub Else MessageBox.Show("iserror = false")
    End Sub
    Private Function Check() As Boolean
        Dim data As String = TextBox2.Text.Trim()
        If data = "" Then
            MessageBox.Show("blank")
            Return True
        Else
            Return False
        End If
    End Function
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim result As Integer = Total(Val(TextBox3.Text), Val(TextBox4.Text))
        If result Then
            MessageBox.Show(result)
        Else
            MessageBox.Show("no")
        End If
    End Sub
    Private Function Total(first, second) As Integer
        Dim answer As Integer = first + second
        Return answer
    End Function
End Class

