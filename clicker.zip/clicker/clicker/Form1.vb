﻿Public Class Form1
    Dim num As Integer = 0 'define num once as global variable to prevent unwanted redefinition;'
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnClicker.Click
        num += 1
        lblCount.Text = num 'increase num each time button is clicked and displays it on label;'
    End Sub
End Class
