﻿Public Class Form1
    Private Sub btnButton1_Click(sender As Object, e As EventArgs) Handles btnButton1.Click
        Dim number1 As Integer
        Dim number2 As Integer
        Dim answer As Integer

        number1 = 3
        number2 = 5

        answer = number1 + number2

        TextBox1.Text = answer


    End Sub
End Class
