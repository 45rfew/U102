﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnLargest = New System.Windows.Forms.Button()
        Me.txtInput1 = New System.Windows.Forms.TextBox()
        Me.txtInput2 = New System.Windows.Forms.TextBox()
        Me.txtInput3 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnLargest
        '
        Me.btnLargest.Location = New System.Drawing.Point(562, 461)
        Me.btnLargest.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.btnLargest.Name = "btnLargest"
        Me.btnLargest.Size = New System.Drawing.Size(265, 44)
        Me.btnLargest.TabIndex = 0
        Me.btnLargest.Text = "find largest number"
        Me.btnLargest.UseVisualStyleBackColor = True
        '
        'txtInput1
        '
        Me.txtInput1.Location = New System.Drawing.Point(592, 133)
        Me.txtInput1.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtInput1.Name = "txtInput1"
        Me.txtInput1.Size = New System.Drawing.Size(196, 31)
        Me.txtInput1.TabIndex = 1
        '
        'txtInput2
        '
        Me.txtInput2.Location = New System.Drawing.Point(592, 231)
        Me.txtInput2.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtInput2.Name = "txtInput2"
        Me.txtInput2.Size = New System.Drawing.Size(196, 31)
        Me.txtInput2.TabIndex = 2
        '
        'txtInput3
        '
        Me.txtInput3.Location = New System.Drawing.Point(594, 327)
        Me.txtInput3.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.txtInput3.Name = "txtInput3"
        Me.txtInput3.Size = New System.Drawing.Size(196, 31)
        Me.txtInput3.TabIndex = 3
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1600, 865)
        Me.Controls.Add(Me.txtInput3)
        Me.Controls.Add(Me.txtInput2)
        Me.Controls.Add(Me.txtInput1)
        Me.Controls.Add(Me.btnLargest)
        Me.Margin = New System.Windows.Forms.Padding(6, 6, 6, 6)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnLargest As Button
    Friend WithEvents txtInput1 As TextBox
    Friend WithEvents txtInput2 As TextBox
    Friend WithEvents txtInput3 As TextBox
End Class
