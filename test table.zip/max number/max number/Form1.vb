﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnLargest.Click
        Dim arr = {txtInput1.Text, txtInput2.Text, txtInput3.Text} 'transfer raw textbox inputs into array 
        For Each item In arr 'loop array 
            If Not IsNumeric(item) Then
                MessageBox.Show("incorrect input type - ensure that all textboxes are filled with nummbers")
                'check if each array element is numeric; if not asks for correct input type 
                Return
            End If
        Next
        Array.Sort(arr) 'sort array 
        MessageBox.Show("largest value is " & arr(arr.Length - 1)) 'print the largest array element 
    End Sub
End Class
