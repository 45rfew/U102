﻿Public Class Form1
    Private Sub btnEqual_Click(sender As Object, e As EventArgs) Handles btnEqual.Click
        Dim prices() As Integer = {2, 3, 4, 5, 6}, names() As String = {"chkApple", "chkBanana", "chkOrange", "chkGrape", "chkPear"},
        total As Integer, i As Integer = 0
        'If chkApple.Checked Then total += prices(0)
        'If chkBanana.Checked Then total += prices(1)
        'If chkOrange.Checked Then total += prices(2)
        'If chkGrape.Checked Then total += prices(3)
        'If chkPear.Checked Then total += prices(4)
        For Each item As String In names
            MessageBox.Show(TypeOf item)
            'If item.checked Then
            '    total += prices(i)
            '    i += 1
            'End If
        Next
        lblTotal.Text = "total cost: $ " & total
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
