﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkApple = New System.Windows.Forms.CheckBox()
        Me.chkBanana = New System.Windows.Forms.CheckBox()
        Me.chkOrange = New System.Windows.Forms.CheckBox()
        Me.chkGrape = New System.Windows.Forms.CheckBox()
        Me.chkPear = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnEqual = New System.Windows.Forms.Button()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnExit)
        Me.GroupBox1.Controls.Add(Me.lblTotal)
        Me.GroupBox1.Controls.Add(Me.btnEqual)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.chkPear)
        Me.GroupBox1.Controls.Add(Me.chkGrape)
        Me.GroupBox1.Controls.Add(Me.chkOrange)
        Me.GroupBox1.Controls.Add(Me.chkBanana)
        Me.GroupBox1.Controls.Add(Me.chkApple)
        Me.GroupBox1.Location = New System.Drawing.Point(379, 119)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 219)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'chkApple
        '
        Me.chkApple.AutoSize = True
        Me.chkApple.Location = New System.Drawing.Point(7, 20)
        Me.chkApple.Name = "chkApple"
        Me.chkApple.Size = New System.Drawing.Size(52, 17)
        Me.chkApple.TabIndex = 0
        Me.chkApple.Text = "apple"
        Me.chkApple.UseVisualStyleBackColor = True
        '
        'chkBanana
        '
        Me.chkBanana.AutoSize = True
        Me.chkBanana.Location = New System.Drawing.Point(7, 43)
        Me.chkBanana.Name = "chkBanana"
        Me.chkBanana.Size = New System.Drawing.Size(62, 17)
        Me.chkBanana.TabIndex = 1
        Me.chkBanana.Text = "banana"
        Me.chkBanana.UseVisualStyleBackColor = True
        '
        'chkOrange
        '
        Me.chkOrange.AutoSize = True
        Me.chkOrange.Location = New System.Drawing.Point(6, 66)
        Me.chkOrange.Name = "chkOrange"
        Me.chkOrange.Size = New System.Drawing.Size(59, 17)
        Me.chkOrange.TabIndex = 2
        Me.chkOrange.Text = "orange"
        Me.chkOrange.UseVisualStyleBackColor = True
        '
        'chkGrape
        '
        Me.chkGrape.AutoSize = True
        Me.chkGrape.Location = New System.Drawing.Point(6, 89)
        Me.chkGrape.Name = "chkGrape"
        Me.chkGrape.Size = New System.Drawing.Size(53, 17)
        Me.chkGrape.TabIndex = 3
        Me.chkGrape.Text = "grape"
        Me.chkGrape.UseVisualStyleBackColor = True
        '
        'chkPear
        '
        Me.chkPear.AutoSize = True
        Me.chkPear.Location = New System.Drawing.Point(7, 112)
        Me.chkPear.Name = "chkPear"
        Me.chkPear.Size = New System.Drawing.Size(47, 17)
        Me.chkPear.TabIndex = 4
        Me.chkPear.Text = "pear"
        Me.chkPear.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(111, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(19, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "$2"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(111, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(19, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "$3"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(111, 67)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(19, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "$4"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(111, 93)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(19, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "$5"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(111, 116)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(19, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "$6"
        '
        'btnEqual
        '
        Me.btnEqual.Location = New System.Drawing.Point(7, 158)
        Me.btnEqual.Name = "btnEqual"
        Me.btnEqual.Size = New System.Drawing.Size(75, 23)
        Me.btnEqual.TabIndex = 10
        Me.btnEqual.Text = "calculate"
        Me.btnEqual.UseVisualStyleBackColor = True
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Location = New System.Drawing.Point(89, 158)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(68, 13)
        Me.lblTotal.TabIndex = 11
        Me.lblTotal.Text = "total cost: $0"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(6, 190)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnEqual As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents chkPear As Windows.Forms.CheckBox
    Friend WithEvents chkGrape As Windows.Forms.CheckBox
    Friend WithEvents chkOrange As Windows.Forms.CheckBox
    Friend WithEvents chkBanana As Windows.Forms.CheckBox
    Friend WithEvents chkApple As Windows.Forms.CheckBox
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnExit As Button
End Class
