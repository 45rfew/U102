﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim arr = {TextBox1.Text, TextBox2.Text, TextBox3.Text} 'transfer textbox inputs into array 
        For Each item In arr 'loop array 
            If Not IsNumeric(item) Then
                MessageBox.Show("incorrect input type") 'check if each array element is numeric; if not asks for correct input type 
                Return
            End If
        Next
        Array.Sort(arr) 'sort array 
        MessageBox.Show("largest value is " & arr(arr.Length - 1)) 'print the largest array element 
    End Sub
End Class
