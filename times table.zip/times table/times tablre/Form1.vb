﻿Public Class Form1
    Private Sub btnInit_Click(sender As Object, e As EventArgs) Handles btnInit.Click
        Dim number As Integer = Val(txtStart.Text), number2 As Integer = Val(txtEnd.Text), mult As Integer = Val(txtIncrement.Text) Or 2, answer As Integer, i As Integer
        ListBox1.Items.Clear()
        For i = number To number2
            answer *= i
            ListBox1.Items.Add(i & " times " & mult & " = " & answer)
        Next i
    End Sub
End Class
